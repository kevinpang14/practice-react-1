const Hello = ({ name = "World" }) => {
  return <h1>Hello, {name}!</h1>;
};

export default Hello;
